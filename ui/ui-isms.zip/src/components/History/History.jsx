import React, { useEffect } from "react";
import "./History.css";
import io from "socket.io-client";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { addEventState, saveEvent } from "../../redux/ISMS_Slice";
import VisibilityIcon from "@mui/icons-material/Visibility";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const socket = io.connect("http://localhost:8080");

function History() {
  const state = useSelector((state) => state.ISMS);
  let dispatch = useDispatch();

  // show marker on map by blinking - saving event in global state
  const handleShowMarkerEvent = (event, markerDevice) => {
    dispatch(
      saveEvent({
        ...event,
        coordinates: {
          lat: markerDevice.LocationX,
          lng: markerDevice.LocationY,
        },

        show: true,
      })
    );
  };

  // lisening to Back-end
  useEffect(() => {
    socket.on("eventEmiter", (data) => {
      dispatch(addEventState(data));
      sessionStorage.setItem("event", JSON.stringify(data));
      // console.log("EVENT: ");
      console.log(data);
    });
    console.log(state);

    socket.on("statusEmiter", (data) => {
      sessionStorage.setItem("status", JSON.stringify(data));
    });
  }, [socket]);

  return (
    <div className="History">
      <div className="History__header header span">
        <span>{`History - (${state.Jetty})`}</span>
      </div>
      <div className="History__wrapper">
        <Paper sx={{ width: "100%", overflow: "hidden" }}>
          <TableContainer
            sx={{ maxHeight: 256, color: "white", backgroundColor: "#515151" }}
          >
            <Table
              stickyHeader
              sx={{ minWidth: 650 }}
              aria-label="simple table"
            >
              <TableHead>
                <TableRow>
                  <TableCell align="left">Show</TableCell>
                  <TableCell className="History__thTd" align="left">
                    Date Time
                  </TableCell>
                  <TableCell align="left">Level</TableCell>
                  <TableCell align="left">Name</TableCell>
                  <TableCell align="left">Device ID</TableCell>
                  <TableCell align="left">Message</TableCell>
                </TableRow>
              </TableHead>
              <TableBody className="History__table">
                {state.events.map((event) => {
                  let { Name } = state.integrationDevices.find(
                    (device) => device.Id === event.InvokerId
                  );
                  let markerOnMap = state.markers.find(
                    (marker) => marker.id === event.InvokerId
                  );
                  return (
                    <TableRow
                      classes="History__table-row"
                      key={event.EventId}
                      className="Settings__TableCell"
                    >
                      <TableCell sx={{ color: "white" }} align="center">
                        {markerOnMap === undefined ? (
                          <div></div>
                        ) : (
                          <VisibilityIcon
                            onClick={() => {
                              let markerDevice = state.integrationDevices.find(
                                (device) => device.Id === event.InvokerId
                              );
                              if (markerDevice.HasLocation) {
                                handleShowMarkerEvent(event, markerDevice);
                              }
                            }}
                            sx={{ cursor: "pointer" }}
                          />
                        )}
                      </TableCell>
                      <TableCell
                        className="History__td"
                        sx={{ color: "white" }}
                        align="left"
                      >
                        {`${moment(event.RegistrationTime).format(
                          "DD-MM-YYYY HH:mm:ss"
                        )}`}
                      </TableCell>
                      <TableCell sx={{ color: "white" }} align="center">
                        {event.ImportanceLevel}
                      </TableCell>
                      <TableCell sx={{ color: "white" }} align="left">
                        {Name}
                      </TableCell>
                      <TableCell
                        sx={{ color: "white" }}
                        align="left"
                      >{`${event.InvokerId}`}</TableCell>
                      <TableCell sx={{ color: "white" }} align="left">
                        {event.CodeDescription}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* <div className="History__table-header">
          <h4 style={{ flex: 0.88 }}>{`Show`}</h4>
          <h4 style={{ flex: 2.8 }}>{`Date Time`}</h4>
          <h4 style={{ flex: 0.8 }}>{`Level`}</h4>
          <h4 style={{ flex: 3 }}>{`Name`}</h4>
          <h4 style={{ flex: 4 }}>{`Device ID`}</h4>
          <h4 style={{ flex: 4 }}>{`Message`}</h4>
        </div>
        <div className="History__table-body">
          {
            state.events.map((event) => {
              let { Name } = state.integrationDevices.find(
                (device) => device.Id === event.InvokerId
              );
              let markerOnMap = state.markers.find(
                (marker) => marker.id === event.InvokerId
              );

              return (
                <div key={event.EventId} className="History__table-body__row">
                  <span
                    className="History__table-body__row-td"
                    style={{
                      flex: 0.88,
                      textAlign: "center",
                      paddingLeft: "5px",
                    }}
                  >
                    {markerOnMap === undefined ? (
                      <div
                        style={{ borderBottom: "none" }}
                        className="History__table-body__row"
                      ></div>
                    ) : (
                      <VisibilityIcon
                        onClick={() => {
                          let markerDevice = state.integrationDevices.find(
                            (device) => device.Id === event.InvokerId
                          );
                          if (markerDevice.HasLocation) {
                            handleShowMarkerEvent(event, markerDevice);
                          }
                        }}
                        sx={{ cursor: "pointer" }}
                      />
                    )}
                  </span>
                  <span
                    className="History__table-body__row-td"
                    style={{ flex: 2.8 }}
                  >
                    {`${moment(event.RegistrationTime).format(
                      "DD-MM-YYYY HH:mm:ss"
                    )}`}
                  </span>
                  <span
                    style={{
                      flex: 0.8,
                      textAlign: "center",
                      paddingLeft: "5px",
                    }}
                    className="History__table-body__row-td"
                  >
                    {event.ImportanceLevel}
                  </span>

                  <span
                    style={{ flex: 3 }}
                    className="History__table-body__row-td"
                  >
                    {Name}
                  </span>
                  <span
                    style={{ flex: 4 }}
                    className="History__table-body__row-td"
                  >{`${event.InvokerId}`}</span>
                  <span
                    style={{ flex: 4 }}
                    className="History__table-body__row-td"
                  >
                    {event.CodeDescription}
                  </span>
                </div>
              );
            }) // reverse the order of array
            // .reverse()
          }
        </div> */}
      </div>
    </div>
  );
}

export default History;
